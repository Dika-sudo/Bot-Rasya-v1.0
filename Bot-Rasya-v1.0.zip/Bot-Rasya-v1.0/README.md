## 𝙲𝚙𝚝𝚢𝙼𝙱𝚘𝚝𝚜 ☂︎
BOT WHATSAPP YANG BISA DIGUNAKAN DI TERMUX







## CARA INSTALL
# TERMUX
```bash
> download termux
> buka
> pkg install git
> pkg install ffmpeg
> pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/AriiqDesign/CptyMBots
> cd CptyMBots
> bash install.sh
> node index.js
```


# FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS                             |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,IG,TWT DOWNLOADER        |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             |
|       ✅       | KAMING SUN                        |

ket : ✅ : aktif




## THANKS TO
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)

## DONASI
* [`pulsa:08813100198`] 
